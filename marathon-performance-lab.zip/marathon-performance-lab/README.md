# Marathon Performance Lab

An installable, offline-capable, mobile-first marathon training PWA with an 18-week Daniels-inspired 2Q plan, goal-based pace guide, training log, and recovery check-ins.

## Deploy free with GitHub Pages

1. Create a new **public** GitHub repository, e.g. `marathon-lab`.
2. Upload all files in this folder to the **root** of the repository (not the ZIP itself).
3. In the repository, open **Settings → Pages → Build and deployment**, select **Deploy from a branch**, branch `main`, folder `/ (root)`, and save.
4. Wait for GitHub Pages to publish the site. Your URL will normally be `https://YOUR-USERNAME.github.io/marathon-lab/`.
5. Open the published HTTPS URL in **Safari on your iPhone**. Tap **Share → Add to Home Screen → Add**. If prompted, enable **Open as Web App**.
6. Open the new icon from the Home Screen. For offline access, open it online once to allow the service worker to cache files.

You can also deploy the folder to Netlify, Cloudflare Pages, or another static HTTPS host.

## Storage and backup

Workouts, settings, and recovery entries are saved to browser `localStorage` on the current device and origin. They do **not** automatically sync to other devices. The installed Home Screen app may use a separate storage context from Safari, so use the app consistently and regularly **export a JSON backup** from Settings. Restore backups with the file picker. CSV export covers workouts.

Clearing site data, private browsing, reinstalling, or device changes can erase local entries. The app has no account system or remote database. This is local persistence, not cloud synchronization.

## Notes

- The 18-week workouts are original, illustrative Daniels-style 2Q examples, not official copied tables or personalized medical advice.
- E/T/I/R paces are approximate goal-based ranges. Calibrate with a recent race/VDOT assessment.
- The recovery score is not validated for injury prediction.
- The app is keyboard-friendly, has visible focus styles, readable contrast, labeled form controls, and reduced-motion support.
- To test locally: run `python -m http.server 8000` inside the folder, then visit `http://localhost:8000`. Offline installation requires HTTPS deployment (localhost is a development exception).
